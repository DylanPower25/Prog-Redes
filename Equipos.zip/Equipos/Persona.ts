abstract class Persona{
nombre: String;
fechaNac: Date;
provincia: any;
numCamiseta: number;
HistorialEquipos: any;


constructor(Provincias:Provincias, Nombre:String, FechaNac:Date, NumCamiseta:number, HistoialEquipos: any){
this.provincia=Provincias;
this.nombre= Nombre;
this.fechaNac = FechaNac;
this.numCamiseta = NumCamiseta;
this.HistorialEquipos= HistoialEquipos;
}


}