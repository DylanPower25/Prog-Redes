interface JugadorCampo extends Jugador {
    porcentajeGolesConvertidos: number;
    cantidadAsistencias: number;
  }

  