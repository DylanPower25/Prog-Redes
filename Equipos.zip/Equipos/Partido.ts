class Partido{
  private jugadores: Jugador[];
    fecha: Date;
    golesContra: number;
    asistencias: number;
    amarillasPartido:Map<Jugador,number>;
    rojasPartido:Map<Jugador,number>;

    constructor(fecha:Date, golesContra:number,asistencias: number, Equipo:EquipoFutbolArgentino, jugadores:Jugador,amarillas:Map<Jugador,number>,rojas:Map<Jugador,number>){
      this.fecha = fecha;
      this.golesContra = golesContra;
      this.asistencias = asistencias;
      this.jugadores = [];
      this.amarillasPartido = amarillas;
      this.rojasPartido = rojas;
    }
  }