class Fichaje extends EquipoFutbolArgentino{
    
    Jugdores!: Set<Jugador>;
    Arqueros!: Set<Arquero>;
    jugador!: Jugador;
    arqueros!: Arquero;
    equipo!: EquipoFutbolArgentino;


    

    ContratarJugador?(nombre: String, posicion: any, fechaNac: any, provincia: Provincias, numCamiseta: number, HistoialEquipos: any): void {
        if (this.equipo != HistoialEquipos && this.jugador.cantAsists > 10 && this.jugador.porcDeGoles > 30.0) {
            console.log("Se ha unido el jugador: " + nombre + numCamiseta + provincia + posicion + fechaNac)
        }else{
            throw new Error("Error, El Jugador ya pertenece al equipo");
        }
    }

    ContratarArquero?(nombre: String, posicion: any, fechaNac: any, provincia: Provincias, numCamiseta: number, HistoialEquipos: any) : void{
        if (this.equipo.arqueros.PorcDeAtajadas < 60.0 && this.equipo.arqueros.CantGolesRecibidos < 10){

        }
    }
    
}