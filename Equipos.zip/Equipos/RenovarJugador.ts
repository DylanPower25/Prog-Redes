class RenovarJugador extends EquipoFutbolArgentino{
    Jugdores!: Set<Jugador>;
    Arqueros!: Set<Arquero>;
    arqueros!: Arquero;
    equipo!:EquipoFutbolArgentino;


    RenovarJugador?(fechaNac: Date, HistorialEquipos: any) : void{
        if (/*¿¿¿this.equipo.jugadores.fechaNac <  &&???*/ (this.equipo = this.equipo)) {
            
        }else {
            throw new Error ("El jugador no cumple con los requisitos minimos");
        }
    }
}