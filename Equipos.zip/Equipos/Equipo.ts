class EquipoFutbolArgentino implements Contrato {
  private nombreClub: string;
  private jugadores: Jugador[];
  private JugadoresSuspendidos : Jugador[];
  private partidos: Partido[];
  private JugadorDeCampo!: JugadorCampo;
    arqueros: Arquero;
  
  
    constructor(nombreClub: string, JugadoresSuspendidos:Jugador) {
    this.nombreClub = nombreClub;
    this.jugadores = [];
    this.partidos = [];
    this.arqueros = arquero;
    this.JugadoresSuspendidos = [];
  }

  contratar(jugador: Jugador): void {
    if (this.validarContrato(jugador)) {
      this.jugadores.push(jugador);
      console.log(`${jugador.nombre} (${jugador.posicion}) se contrató en ${this.nombreClub}.`);
    } else {
      throw new Error("No se pudo contratar al Jugador que quiere");
    }
  }

  renovar(jugador: Jugador, clubOfrecido: string): void {
    if (this.validarRenovacion(jugador, clubOfrecido)) {
      console.log(`${jugador.nombre} (${jugador.posicion}) se renovó en ${this.nombreClub}.`);
    } else {
      throw new Error("No se pudo renovar el Contrato");
    }
  }

  agregarPartido(partido: Partido): void {
    this.partidos.push(partido);
    this.actualizarEstadisticasJugadores(partido);
  }

  private validarContrato(jugador: Jugador): boolean {
    if (jugador.HistorialEquipos.includes(this.nombreClub)) {
      return false;
    }

    if ("porcentajeAtajadas" in jugador) {
      const arquero = jugador as unknown as Arquero;
      return arquero.PorcDeAtajadas > 60 && arquero.CantGolesRecibidos < 10;
    } else {
      const jugadorCampo = jugador as JugadorCampo;
      return jugadorCampo.porcentajeGolesConvertidos > 30 && jugadorCampo.cantidadAsistencias > 10;
    }
  }

  private validarRenovacion(jugador: Jugador, clubOfrecido: string): boolean {
    if (jugador.HistorialEquipos[jugador.HistorialEquipos.length - 1] !== this.nombreClub) {
      return false;
    }

    const edad : any = this.calcularEdad(jugador.get(fechaDeNacimient));
    return edad <= 35 && clubOfrecido === this.nombreClub;
  }

  private actualizarEstadisticasJugadores(partido: Partido): void {
    for (const jugador of this.jugadores) {
      this.JugadorDeCampo.actualizarEstadisticas(partido);
    }
  }

  private calcularEdad(fechaNacimiento: string): number {
    const nacimiento = new Date(fechaNacimiento);
    const hoy = new Date();
    const edad = hoy.getFullYear() - nacimiento.getFullYear();

    if (hoy.getMonth() < nacimiento.getMonth() ||
        (hoy.getMonth() === nacimiento.getMonth() && hoy.getDate() < nacimiento.getDate())) {
      return edad - 1;
    }

    return edad;
  }


  mostrarJugadoresSuspendidos(): void{
    this.JugadoresSuspendidos.forEach(JuagadorActual => {
      console.log(JuagadorActual.nombre+" "+ JuagadorActual.numCamiseta)
    });
  }

  verificarTarjetas(jugador:Jugador): void{
    this.jugadores.forEach((element)=>{
    
if(jugador.tAmarilla > 4 || jugador.tRoja == 1){
    jugador.tAmarilla =0;
    this.JugadoresSuspendidos.push(this.JugadorDeCampo)
}else {
  jugador.tAmarilla ++;
}
    });   
  }
}