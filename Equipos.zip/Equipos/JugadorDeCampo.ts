class JugadorCampo implements JugadorCampo {
  nombre!: string;
  fechaNacimiento!: string;
  posicion!: string;
  provincia!: string;
  historialEquipos!: string[];
  numeroCamiseta!: number;
  porcentajeGolesConvertidos!: number;
  cantidadAsistencias!: number;

  constructor(datos: JugadorCampo) {
    Object.assign(this, datos);
  }

  actualizarEstadisticas(partido: Partido): void {
    this.porcentajeGolesConvertidos += partido.golesContra > 0 ? 0 : 10; // Ejemplo de actualización, puedes ajustar según tus necesidades.
    this.cantidadAsistencias += partido.asistencias;
  }
}