interface Jugador extends Persona{
get(fechaDeNacimient: Date): string;
cantAsists : number;
porcDeGoles : number;
posicion: any;
fechaNac: Date;
tRoja: number;
tAmarilla: number;
ContratarJugador?:(nombre: String, posicion: any, fechaNac: Date, provincia: Provincias, numCamiseta: number, HistorialEquipos: any) => void;
RenovarJugador?:(fechaNac: Date, HistorialEquipos: any) => void;
}

const fechaDeNacimiento: Date = new Date(1990, 9, 15)



const jugador: Jugador = {
    cantAsists: 13,
    porcDeGoles: 12,
    posicion: Posicion.DEFENSA,
    nombre: 'holo',
    fechaNac: fechaDeNacimiento,
    provincia: Provincias.Chaco,
    numCamiseta: 10,
    HistorialEquipos: null,
    tRoja : 0,
    tAmarilla : 0,
    get: function (fechaDeNacimient: Date): string {
        throw new Error("Function not implemented.");
    },
    
};





