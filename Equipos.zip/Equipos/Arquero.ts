interface Arquero extends Persona{
    PorcDeAtajadas : any;
    CantGolesRecibidos : number;
    
    ContratarArquero?(nombre: String, fechaNac: Date, provincia: Provincias, numCamiseta: number, HistoialEquipos: any) : void;
    }
    
    const fechaDeNacimient: Date = new Date(1990, 9, 15)
    
    
    const arquero: Arquero = {
    PorcDeAtajadas : 55.62,
    CantGolesRecibidos : 0,
    nombre: 'holo',
    fechaNac: fechaDeNacimient,
    provincia: Provincias.Chaco,
    numCamiseta: 10,
    HistorialEquipos: null
    
    };