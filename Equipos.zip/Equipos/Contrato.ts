interface Contrato {
    contratar(jugador: Jugador): void;
    renovar(jugador: Jugador, clubOfrecido: string): void;
  }