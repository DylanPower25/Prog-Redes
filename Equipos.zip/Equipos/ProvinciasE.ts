enum Provincias{
    Buenos_Aires, Buenos_Aires_Capital_Federal, Catamarca, Chaco, Chubut, Córdoba, Corrientes, Entre_Ríos, Formosa, Jujuy, La_Pampa, La_Rioja, Mendoza, Misiones, Neuquen, Río_Negro, Salta, San_Juan, San_Luís, Santa_Cruz, Santa_Fe, Santiago_del_Estero, Tierra_del_Fuego, Antártida_e_Islas_del_Atlántico_Sur, Tucumán
}